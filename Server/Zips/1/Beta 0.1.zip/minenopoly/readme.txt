Hi :)
This example datapack has been created by Skorp.

Use this readme to give some information about this datapack to anyone, who might work with it, needs an installation guide or just describe it for later recognisation.

You find the wiki article on datapacks under:
	https://minecraft.gamepedia.com/Data_pack

Have fun coding stuff :)
-Skorp